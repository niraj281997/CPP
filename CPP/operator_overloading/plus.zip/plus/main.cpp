#include "defination.cpp"

int main()
{
	node a1;
//	node b1;
	a1.setdata(2,4);
	node b1=a1;
	node c1=b1+a1;
	return 0;

}
